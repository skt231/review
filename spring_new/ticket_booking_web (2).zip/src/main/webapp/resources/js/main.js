const word='babel';
let test =() => {console.log('I know ${word')}
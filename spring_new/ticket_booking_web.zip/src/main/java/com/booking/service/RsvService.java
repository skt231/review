package com.booking.service;

import java.sql.Date;
import java.util.List;

import com.booking.dto.RsvDto;

public interface RsvService {
	public void RsvInsert(RsvDto Rsv) throws Exception;

	public List<RsvDto> getRsvId(Integer userid) throws Exception;
	
	public void deleteRsv(Integer userid,String selectedSeats,String mt20id) throws Exception;
	
	/*
	 * public List<RsvDto> RsvSeats(String mt20id,String time,String showdate)throws
	 * Exception;
	 */
}

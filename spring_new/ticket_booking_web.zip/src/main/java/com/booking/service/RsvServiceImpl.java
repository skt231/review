package com.booking.service;

import java.sql.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.RsvDao;
import com.booking.dto.RsvDto;

@Service
public class RsvServiceImpl implements RsvService {

	@Autowired
	private SqlSession sqlsession;

	@Override
	public void RsvInsert(RsvDto Rsv) throws Exception {
		RsvDao rsvDao = sqlsession.getMapper(RsvDao.class);
		rsvDao.RsvInsert(Rsv);
	}

	@Override
	public List<RsvDto> getRsvId(Integer userid) throws Exception {
		RsvDao rsvDao = sqlsession.getMapper(RsvDao.class);
		List<RsvDto> rsv = rsvDao.getRsvId(userid);
		System.out.println(userid);
		System.out.println(rsv);
		return rsv;
	}

	@Override
	public void deleteRsv(Integer userid, String selectedSeats, String mt20id) throws Exception {
		RsvDao rsvDao = sqlsession.getMapper(RsvDao.class);
		rsvDao.deleteRsv(userid, selectedSeats, mt20id);
	}

	/*
	 * @Override public List<RsvDto> RsvSeats(String mt20id, String time, String
	 * showdate) throws Exception { RsvDao rsvDao =
	 * sqlsession.getMapper(RsvDao.class); List<RsvDto> rsv =
	 * rsvDao.RsvSeats(mt20id, time, showdate); System.out.println(mt20id);
	 * System.out.println(time); System.out.println(showdate);
	 * System.out.println(rsv); return rsv; }
	 */

}

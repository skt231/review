package com.booking.dto;

import java.sql.Date;

public class RsvDto {
	private Integer userid;
    private String username;
    private String selectedSeats;
    private Long totalAmount;
    private String mt20id;
    private Date showdate;
    private String location;
    private String time;
    private String title;
    
    RsvDto(){
    };
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	@Override
	public String toString() {
		return "RsvDto [userid=" + userid + ", username=" + username + ", selectedSeats=" + selectedSeats
				+ ", totalAmount=" + totalAmount + ", mt20id=" + mt20id + ", showdate=" + showdate + ", location="
				+ location + ", time=" + time + ", title=" + title + "]";
	}
	public String getSelectedSeats() {
		return selectedSeats;
	}
	public void setSelectedSeats(String selectedSeats) {
		this.selectedSeats = selectedSeats;
	}
	public Long getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getMt20id() {
		return mt20id;
	}
	public void setMt20id(String mt20id) {
		this.mt20id = mt20id;
	}
	public Date getShowdate() {
		return showdate;
	}
	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}
